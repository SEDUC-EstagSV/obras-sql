-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.4.25-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              12.3.0.6589
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para seduc_db
CREATE DATABASE IF NOT EXISTS `seduc_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `seduc_db`;

-- Copiando estrutura para view seduc_db.contratoview
-- Criando tabela temporária para evitar erros de dependência de VIEW
CREATE TABLE `contratoview` (
	`cd_Contrato` INT(11) NOT NULL,
	`dt_AnoContrato` VARCHAR(10) NULL COLLATE 'utf8_general_ci',
	`tp_Servico` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`dt_Inicial` DATETIME NULL,
	`dt_Final` DATETIME NULL,
	`num_contrato` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`pr_Total` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`cd_situacao` INT(11) NOT NULL,
	`nm_situacao` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`cd_Fornecedor` INT(11) NOT NULL,
	`nm_Fornecedor` VARCHAR(45) NULL COLLATE 'utf8_general_ci'
) ENGINE=MyISAM;

-- Copiando estrutura para view seduc_db.escolaview
-- Criando tabela temporária para evitar erros de dependência de VIEW
CREATE TABLE `escolaview` (
	`cd_Escola` INT(11) NOT NULL,
	`cd_statusEscola` INT(11) NOT NULL,
	`nm_Escola` VARCHAR(500) NULL COLLATE 'utf8_general_ci',
	`ds_Local` VARCHAR(500) NULL COLLATE 'utf8_general_ci',
	`nm_statusEscola` VARCHAR(45) NULL COLLATE 'utf8_general_ci'
) ENGINE=MyISAM;

-- Copiando estrutura para view seduc_db.obraview
-- Criando tabela temporária para evitar erros de dependência de VIEW
CREATE TABLE `obraview` (
	`cd_Obra` INT(11) NOT NULL,
	`nm_Contratante` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`tp_AtividadeDescricao` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`cd_situacaoObra` INT(11) NOT NULL,
	`nm_situacaoObra` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`cd_Escola` INT(11) NOT NULL,
	`nm_Escola` VARCHAR(500) NULL COLLATE 'utf8_general_ci',
	`ds_Local` VARCHAR(500) NULL COLLATE 'utf8_general_ci',
	`num_contrato` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`tp_Servico` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`dt_Inicial` DATETIME NULL,
	`dt_Final` DATETIME NULL,
	`pr_Total` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`nm_Fornecedor` VARCHAR(45) NULL COLLATE 'utf8_general_ci'
) ENGINE=MyISAM;

-- Copiando estrutura para view seduc_db.relatorioview
-- Criando tabela temporária para evitar erros de dependência de VIEW
CREATE TABLE `relatorioview` (
	`cd_Relatorio` INT(11) NOT NULL,
	`num_Relatorio` INT(11) NOT NULL,
	`nm_TecResponsavel` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`ds_Email_TecResponsavel` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`nm_LocResponsavel` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`dt_Carimbo` DATETIME NULL,
	`tp_AtivRealizada` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`pr_Decorrido` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`nm_Dia` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`qt_totalMaoDeObra` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`qt_Ajudantes` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`qt_Eletricistas` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`qt_Mestres` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`qt_Pedreiros` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`qt_Serventes` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`qt_MaoDireta` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`pt_Conclusao` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`tp_Comentario` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`pr_Vencer` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`cd_situacaoRelatorio` INT(11) NOT NULL,
	`nm_situacaoRelatorio` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`cd_tipoTempo` INT(11) NOT NULL,
	`nm_tipoTempo` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`cd_tipoCondicao` INT(11) NOT NULL,
	`nm_tipoCondicao` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`cd_Obra` INT(11) NOT NULL,
	`tp_AtividadeDescricao` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`nm_Contratante` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`cd_situacaoObra` INT(11) NOT NULL,
	`nm_situacaoObra` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`cd_Escola` INT(11) NOT NULL,
	`nm_Escola` VARCHAR(500) NULL COLLATE 'utf8_general_ci',
	`ds_Local` VARCHAR(500) NULL COLLATE 'utf8_general_ci',
	`cd_Contrato` INT(11) NOT NULL,
	`dt_AnoContrato` VARCHAR(10) NULL COLLATE 'utf8_general_ci',
	`tp_Servico` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`dt_Inicial` DATETIME NULL,
	`dt_Final` DATETIME NULL,
	`num_contrato` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`pr_Total` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`cd_situacao` INT(11) NOT NULL,
	`nm_situacao` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`cd_Fornecedor` INT(11) NOT NULL,
	`nm_Fornecedor` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`ds_Email` VARCHAR(45) NULL COLLATE 'utf8_general_ci',
	`cd_tipoPeriodo` INT(11) NOT NULL,
	`Periodo` MEDIUMTEXT NULL COLLATE 'utf8_general_ci'
) ENGINE=MyISAM;

-- Copiando estrutura para view seduc_db.contratoview
-- Removendo tabela temporária e criando a estrutura VIEW final
DROP TABLE IF EXISTS `contratoview`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `contratoview` AS SELECT c.cd_Contrato, c.dt_AnoContrato, c.tp_Servico, 
			c.dt_Inicial, c.dt_Final, c.num_contrato, c.pr_Total,
			stc.cd_situacao, stc.nm_situacao, f.cd_Fornecedor, f.nm_Fornecedor
	FROM contrato c 
	INNER JOIN situacao_contrato stc
	ON c.cd_situacao = stc.cd_situacao
	INNER JOIN fornecedor f
	ON c.cd_Fornecedor = f.cd_Fornecedor ;

-- Copiando estrutura para view seduc_db.escolaview
-- Removendo tabela temporária e criando a estrutura VIEW final
DROP TABLE IF EXISTS `escolaview`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `escolaview` AS SELECT e.*, ste.nm_statusEscola FROM escola e 
		INNER JOIN status_escola ste 
		ON e.cd_statusEscola = ste.cd_statusEscola
		
                                
-- SELECT u.*, f.nm_Fornecedor FROM usuario u LEFT JOIN fornecedor f ON u.cd_Fornecedor = f.cd_Fornecedor ;

-- Copiando estrutura para view seduc_db.obraview
-- Removendo tabela temporária e criando a estrutura VIEW final
DROP TABLE IF EXISTS `obraview`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `obraview` AS SELECT o.cd_Obra, o.nm_Contratante, o.tp_AtividadeDescricao,
		 sto.cd_situacaoObra, sto.nm_situacaoObra, e.cd_Escola, e.nm_Escola, 
		 e.ds_Local, c.num_contrato, c.tp_Servico, c.dt_Inicial, c.dt_Final,
		 c.pr_Total,
		 f.nm_Fornecedor
FROM obra o
INNER JOIN situacao_obra sto
ON o.cd_situacaoObra = sto.cd_situacaoObra
INNER JOIN escola e
ON o.cd_Escola = e.cd_Escola
INNER JOIN escola_has_contrato ehc
ON e.cd_Escola = ehc.cd_Escola
INNER JOIN contrato c
ON ehc.cd_Contrato = c.cd_Contrato
INNER JOIN fornecedor f
ON c.cd_Fornecedor = f.cd_Fornecedor ;

-- Copiando estrutura para view seduc_db.relatorioview
-- Removendo tabela temporária e criando a estrutura VIEW final
DROP TABLE IF EXISTS `relatorioview`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `relatorioview` AS SELECT r.cd_Relatorio, r.num_Relatorio, r.nm_TecResponsavel, 
			r.ds_Email_TecResponsavel, r.nm_LocResponsavel,
			r.dt_Carimbo, r.tp_AtivRealizada, r.pr_Decorrido, r.nm_Dia, r.qt_totalMaoDeObra,
			r.qt_Ajudantes, r.qt_Eletricistas, r.qt_Mestres, r.qt_Pedreiros,
			r.qt_Serventes, r.qt_MaoDireta, r.pt_Conclusao,
			r.tp_Comentario, r.pr_Vencer, str.cd_situacaoRelatorio, str.nm_situacaoRelatorio,
			tpt.cd_tipoTempo, tpt.nm_tipoTempo, tpc.cd_tipoCondicao, tpc.nm_tipoCondicao,
			o.cd_Obra, o.tp_AtividadeDescricao, o.nm_Contratante, sto.cd_situacaoObra, sto.nm_situacaoObra, 
			e.cd_Escola, e.nm_Escola, e.ds_Local, c.cd_Contrato, c.dt_AnoContrato, c.tp_Servico, 
			c.dt_Inicial, c.dt_Final, c.num_contrato, c.pr_Total, stc.cd_situacao, stc.nm_situacao, f.cd_Fornecedor,
			f.nm_Fornecedor, f.ds_Email, tpp.cd_tipoPeriodo, GROUP_CONCAT(tpp.nm_tipoPeriodo SEPARATOR ", ") As Periodo
		FROM relatorio r
		INNER JOIN situacao_relatorio str
		ON r.cd_situacaoRelatorio = str.cd_situacaoRelatorio
		INNER JOIN tipo_tempo tpt
		ON r.cd_tipoTempo = tpt.cd_tipoTempo
		INNER JOIN tipo_condicao tpc
		ON r.cd_tipoCondicao = tpc.cd_tipoCondicao
		INNER JOIN obra o
		ON r.cd_Obra = o.cd_Obra
		INNER JOIN situacao_obra sto
		ON o.cd_Obra = sto.cd_situacaoObra
		INNER JOIN escola e
		ON e.cd_Escola = o.cd_Escola
		INNER JOIN escola_has_contrato ehc
		ON e.cd_Escola = ehc.cd_Escola
		INNER JOIN contrato c
		ON ehc.cd_Contrato = c.cd_Contrato
		INNER JOIN situacao_contrato stc
		ON c.cd_situacao = stc.cd_situacao
		INNER JOIN fornecedor f
		ON c.cd_Fornecedor = f.cd_Fornecedor
		INNER JOIN relatorio_has_tipo_periodo rhtp
		ON r.cd_Relatorio = rhtp.cd_Relatorio
		INNER JOIN tipo_periodo tpp
		ON rhtp.cd_tipoPeriodo = tpp.cd_tipoPeriodo
		GROUP BY rhtp.cd_Relatorio ;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
